function updatetext(){
window.select=document.getElementById("textbox").value;
console.log('Adding: '+ window.select);
document.getElementById("selectionform").innerHTML = `<input value="/MCMv3.3.1/extract.htt" type="hidden" name="url"><br><input type="submit" value="Now click again!">`
window.select.split(/[,\s]+/).forEach(d=> {document.getElementById("selectionform").innerHTML += '<input value='+d+' type="hidden" name="marks">'})
}
