function updatetext(){
window.select=document.getElementById("textbox").value;
console.log('Adding: '+ window.select);
document.getElementById("selectionform").innerHTML = `<input value="/MCMv3.3.1/extract.htt" type="hidden" name="url"><input type="submit" value="Mark Species">`
window.select.replace(' ','').split(",").forEach(d=> {document.getElementById("selectionform").innerHTML += '<input value='+d+' type="hidden" name="marks">'})
}
