window.onload=function(){
     //alert("page load!");
     console.log('Running with the MCMScript Selector extention')

     var s = document.createElement('script');
     // TODO: add "script.js" to web_accessible_resources in manifest.json
     s.src = chrome.extension.getURL('getentries.js');
     s.onload = function() {
         this.remove();
     };
     (document.head || document.documentElement).appendChild(s);



mycode =
'<div>'+
'<h2> Pastable marking of species </h2>'+'<h4>Provided by the MCM Species Selector chrome extention</h4>'+
'<input type="text" id="textbox" name="text_name" style="width: 300px;" onchange=updatetext()></input><br>'+
'<form id="selectionform" action="/MCMv3.3.1/mark.py/add" method="post">'+
//'<input value="eeeeppppp" type="hidden" name="marks">'+
'<input value="/MCMv3.3.1/extract.htt" type="hidden" name="url"><br>'+
'<input type="submit" value="Double-Click Here to Mark"></form><br>'+
'</div>'



document.getElementById('body').innerHTML = mycode + document.getElementById('body').innerHTML




}


/*

'<p id=updatetext>'+
'window.select=document.getElementById("textbox").value;'+
'document.getElementById("selectionform").innerHTML = `<input value="/MCMv3.3.1/extract.htt" type="hidden" name="url"><input type="submit" value="Hit Enter then Click here to Mark"></form>`;'+
'window.select.split(",").forEach(d=>{document.getElementById("selectionform").innerHTML += `<input value="`+d+`" type="show" name="marks">`});'+
+'</p>'+


<input type="text" id="text" name="text_name" style="width: 300px;" />

<form action="/MCMv3.3.1/mark.py/add" method="post">

<input value="eeee" type="hidden" name="marks">

<input value="/MCMv3.3.1/browse.htt?species=DDECO2" type="hidden" name="url">

 <input type="submit" value="Mark">
*/
